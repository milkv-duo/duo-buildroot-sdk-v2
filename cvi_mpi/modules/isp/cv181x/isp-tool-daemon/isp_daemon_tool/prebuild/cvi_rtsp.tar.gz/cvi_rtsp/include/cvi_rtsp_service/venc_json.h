#pragma once
#include <sample_comm.h>

#ifdef __cplusplus
extern "C" {
#endif

int CVI_RTSP_SERVICE_SetVencCfg(const char* venc_json, chnInputCfg *pIc);

#ifdef __cplusplus
}
#endif
